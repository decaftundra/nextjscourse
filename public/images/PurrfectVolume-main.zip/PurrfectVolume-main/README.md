## Purrfect Volume 2 App

Keeps your ears safe limiting the maximum volume for your Mac. Now with Headphone detection.

How to use it / customize it and more information in this [blog post](https://medium.com/trabe/limiting-your-macs-volume-in-2019-f314e20408ab)

How to detect Headphones in this [2020 Update](https://medium.com/p/8623f99ec69f/)

## Download a .zip with the updated app

https://github.com/andion/PurrfectVolume/archive/main.zip
